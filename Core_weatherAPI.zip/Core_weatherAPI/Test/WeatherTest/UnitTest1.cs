using CoreWeatherAPI;
using CoreWeatherAPI.Controllers;
using CoreWeatherAPI.Repo;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net.Http;
using System.Threading.Tasks;

namespace WeatherTest
{
    [TestClass]
    public class UnitTest1
    {
        readonly IMapCities _repository;
        private HttpClient _client;
        private TestServer _server;

        public UnitTest1(IMapCities repository)
        {
            _repository = repository;
        }
        [TestInitialize]
        public void Setup()
        {
            var configuration = new ConfigurationBuilder()
                       .AddJsonFile("appsettings.json")
                       .AddEnvironmentVariables()
                       .Build();

            _server = new TestServer(new WebHostBuilder()
                                       .UseConfiguration(configuration)
                                       .UseStartup<Startup>());
            _client = _server.CreateClient();
        }


        [TestMethod]
        public async Task TestUploadFile()
        {
            // Act
            var response = await _client.GetAsync("/api/values/openweather");
            // Assert
            response.EnsureSuccessStatusCode();

            var resultJson = await response.Content.ReadAsStringAsync();
            //var result = JArray.Parse(resultJson);

            //Assert.AreEqual(1, result.Count);
            //Assert.AreEqual(1, result[0]["categoryId"].Value<int>());
            //Assert.AreEqual("Merchantcategory", result[0]["category"].Value<string>());
            //Assert.AreEqual("description", result[0]["description"].Value<string>());
            //Assert.AreEqual(1, result[0]["userType"].Value<int>());
            //Assert.AreEqual("ACH;WEB;CC", result[0]["requiredPaymentTypes"].Value<string>());
        }
    }
}
