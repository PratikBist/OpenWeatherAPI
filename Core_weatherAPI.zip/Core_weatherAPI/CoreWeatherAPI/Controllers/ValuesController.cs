﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using CoreWeatherAPI.Repo;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using WaetherAPI.Models;
using static WaetherAPI.Models.WeatherDetails;

namespace CoreWeatherAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        readonly IMapCities _repository;
        public ValuesController(IMapCities repository)
        {
            _repository = repository;
        }
       
        // GET api/values
        [HttpGet]
        [Route("openweather")]
        public IActionResult Get()
        {
            string localPath = @"D:\Core_weatherAPI\CoreWeatherAPI\Input\CountryList.txt";
            var txtData = System.IO.File.ReadAllText(localPath);

            WeatherMap weatherMap = _repository.FillCity(txtData);

            foreach (var city in weatherMap.cities)
            {
                if (city.Value != null)
                {
                    string apiKey = "aa69195559bd4f88d79f9aadeb77a8f6";
                    HttpWebRequest apiRequest =
                    WebRequest.Create("http://api.openweathermap.org/data/2.5/weather?q=" +
                    city.Value + "&appid=" + apiKey) as HttpWebRequest;

                    string apiResponse = "";
                    using (HttpWebResponse response = apiRequest.GetResponse() as HttpWebResponse)
                    {
                        StreamReader reader = new StreamReader(response.GetResponseStream());
                        apiResponse = reader.ReadToEnd();

                        ResponseWeather rootObject = JsonConvert.DeserializeObject<ResponseWeather>(apiResponse);

                        string jsonData = JsonConvert.SerializeObject(rootObject, Formatting.Indented);
                        string fileName = city.Value + DateTime.UtcNow.ToString("yyyy-MM-dd HH-mm-ss");

                        string projectDirectory = @"D:\Core_weatherAPI\CoreWeatherAPI\Output\";

                        if (!Directory.Exists(projectDirectory))
                            Directory.CreateDirectory(projectDirectory);

                        System.IO.File.WriteAllText(projectDirectory + fileName + ".json", jsonData);
                    }
                }
            }
            return Ok();
        }

      
    }
}
