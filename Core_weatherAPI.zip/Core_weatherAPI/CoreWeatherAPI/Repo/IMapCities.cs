﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WaetherAPI.Models;

namespace CoreWeatherAPI.Repo
{
    public interface IMapCities
    {
        WeatherMap FillCity(string txtData);
    }
}
