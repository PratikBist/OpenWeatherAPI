﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WaetherAPI.Models;
using CoreWeatherAPI.Repo;

namespace CoreWeatherAPI.Repo
{
    public class MapCities : IMapCities
    {

        public WeatherMap FillCity(string txtData)
        {
            WeatherMap weatherMap = new WeatherMap();
            if (!string.IsNullOrWhiteSpace(txtData))
            {
                var dict = txtData.Split('\n')
                            .Select(x => x.Split('='))
                            .ToDictionary(x => x[0], x => x[1].Replace("\r", ""));

                weatherMap.cities = dict;
            }
            return weatherMap;
        }
    }
}
